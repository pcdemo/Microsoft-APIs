﻿using MyDemos.Utils;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyDemos.Services
{
    public class RoleAssignmentsService
    {
        /// <summary>
        /// Assign use to azure subscription with speical role
        /// </summary>
        /// <param name="aadToken">AAD access token for azure management apis</param>
        /// <param name="subscriptionId">azure subscription id</param>
        /// <param name="roleDefinitionId">the azure role's definition id</param>
        /// <param name="objectId">the user's objectid retrieved from azure graph APIs</param>
        /// <returns></returns>
        static public JObject Create(string aadToken, string subscriptionId, string roleDefinitionId, string objectId)
        {
            string roleAssignmentId = Guid.NewGuid().ToString();
            string requestUrl = string.Format("{0}/subscriptions/{1}/providers/Microsoft.Authorization/roleAssignments/{2}?api-version=2017-10-01-preview", SettingsHelper.AzureRMApiEndpoint, subscriptionId, roleAssignmentId);

            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Authorization", string.Format("{0}{1}", "Bearer ", aadToken));

            string jsonParams = "{" +
                    "\"properties\":{" +
                    "\"roleDefinitionId\":\"" + roleDefinitionId + "\"," +
                    "\"principalId\":\"" + objectId + "\"" +
                    "}" +
                    "}";
            return HttpUtils.DoPut(requestUrl, headers, jsonParams); ;
        }
    }
}
