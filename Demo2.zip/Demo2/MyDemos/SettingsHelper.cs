﻿using System;
using System.Configuration;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyDemos
{
    class SettingsHelper
    {
        #region azure ad tenant details
        public static string AadAuthority
        {
            get { return ConfigurationManager.AppSettings["aad:authority"]; }
        }
        #endregion

        #region azure ad application details
        public static string ClientId
        {
            get { return ConfigurationManager.AppSettings["aad:client-id"]; }
        }
        #endregion

        #region user details
        public static string UserId
        {
            get { return ConfigurationManager.AppSettings["partner-user"]; }
        }
        public static string UserPassword
        {
            get { return ConfigurationManager.AppSettings["partner-password"]; }
        }
        #endregion

        public static string PartnerCenterApiEndpoint
        {
            get { return ConfigurationManager.AppSettings["partnercenter-endpoint"]; }
        }
        public static string PartnerCenterApiResourceId
        {
            get { return ConfigurationManager.AppSettings["partnercenter-resource"]; }
        }

        public static string AzureRMApiEndpoint
        {
            get { return ConfigurationManager.AppSettings["azure-resoure-management-endpoint"]; }
        }

        public static string AzureADGraphApiEndpoint
        {
            get { return ConfigurationManager.AppSettings["azure-ad-graph-endpoint"]; }
        }

        public static string AzureRMApiResourceId
        {
            get { return ConfigurationManager.AppSettings["azure-resoure-management-resource"]; }
        }

        public static string AzureADGraphApiResourceId
        {
            get { return ConfigurationManager.AppSettings["azure-ad-graph-resource"]; }
        }
    }
}
