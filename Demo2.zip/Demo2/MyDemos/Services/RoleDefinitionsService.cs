﻿using MyDemos.Utils;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyDemos.Services
{
    public class RoleDefinitionsService
    {
        /// <summary>
        /// Query role definition id via role name 
        /// </summary>
        /// <param name="aadToken">AAD acesss token for azure management apis</param>
        /// <param name="subscriptionId">the azure susbcription id</param>
        /// <param name="filter">the fiter expression</param>
        /// <returns></returns>
        public static JObject List(string aadToken, string subscriptionId, string filter)
        {
            string requestUrl = string.Format("{0}/subscriptions/{1}/providers/Microsoft.Authorization/roleDefinitions?api-version=2017-05-01&$filter={2}", SettingsHelper.AzureRMApiEndpoint, subscriptionId, filter);

            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Authorization", string.Format("{0}{1}", "Bearer ", aadToken));

            return HttpUtils.DoGet(requestUrl, headers);
        }
    }
}
