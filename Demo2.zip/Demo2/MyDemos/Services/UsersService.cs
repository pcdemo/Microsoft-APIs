﻿using MyDemos.Utils;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyDemos.Services
{
    public class UsersService
    {
        /// <summary>
        /// Query user information from azure graph 
        /// </summary>
        /// <param name="aadToken">AAD access token for azure graph APIs</param>
        /// <param name="filter">the filer expression </param>
        /// <returns></returns>
        public static JObject List(string tenantId,string aadToken,string filter)
        {
            string requestUrl = string.Format("{0}/{1}/users?api-version=1.6&$filter={2}", SettingsHelper.AzureADGraphApiEndpoint, tenantId, filter);

            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Authorization", string.Format("{0}{1}", "Bearer ", aadToken));

            return HttpUtils.DoGet(requestUrl, headers);
        }
    }
}
