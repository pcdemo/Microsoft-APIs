﻿using MyDemos.Utils;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace MyDemos.Services
{
    public class ResouceService
    {
        /// <summary>
        /// Query resouce details and get tags 
        /// </summary>
        /// <param name="aadToken">AAD access token for azure management api</param>
        /// <param name="resouceUrl">the azure resouce's relative url</param>
        /// <param name="apiVersion">the api version of azure management APIs</param>
        /// <returns></returns>
        public static string ListTags(string aadToken, string resouceUrl,string apiVersion)
        {
            string requestUrl = string.Format("{0}{1}?api-version={2}", SettingsHelper.AzureRMApiEndpoint, resouceUrl, apiVersion);

            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Authorization", string.Format("{0}{1}", "Bearer ", aadToken));

            JObject retJson = HttpUtils.DoGet(requestUrl, headers);
            if (retJson == null)
                return "not exist or resouces has been removed";
            Dictionary<string, string> tags = JsonConvert.DeserializeObject<Dictionary<string, string>>(retJson["tags"].ToString());
            StringBuilder builder = new StringBuilder();
            foreach(string tag in tags.Keys)
            {
                builder.AppendFormat("{0}:{1}|", tag, tags[tag]);
            }
            return builder.ToString();
        }

        /// <summary>
        /// Query providers under susbcripton (which contains the api versions of resouces' api)
        /// </summary>
        /// <param name="aadToken"></param>
        /// <param name="subscriptionId"></param>
        /// <returns></returns>
        public static JObject ListProvider(string aadToken,string subscriptionId)
        {
            string requestUrl = string.Format("{0}/subscriptions/{1}/providers?api-version=2017-05-10", SettingsHelper.AzureRMApiEndpoint, subscriptionId);

            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Authorization", string.Format("{0}{1}", "Bearer ", aadToken));

            return HttpUtils.DoGet(requestUrl, headers);
        }
    }
}
