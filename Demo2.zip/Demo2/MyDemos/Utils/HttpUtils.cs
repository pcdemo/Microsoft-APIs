﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace MyDemos.Utils
{
    public class HttpUtils
    {
        /// <summary>
        /// Http Get
        /// </summary>
        /// <param name="url"></param>
        /// <param name="headers">headers</param>
        /// <returns></returns>
        public static JObject DoGet(string url, Dictionary<string, string> headers)
        {
            //Console.WriteLine("url:" + url);
            var request = WebRequest.Create(url);
            if (null != headers)
            {
                //Console.WriteLine("headers start");
                foreach (string key in headers.Keys)
                {
                    //Console.WriteLine(key+":"+ headers[key]);
                    request.Headers.Add(key, headers[key]);
                }
                //Console.WriteLine("headers end");
            }
            request.Method = "GET";
            try
            {
                var response = request.GetResponse();
                using (var reader = new StreamReader(response.GetResponseStream()))
                {
                    var responseContent = reader.ReadToEnd();
                    //Console.WriteLine("responseContent:" + responseContent);
                    var retJson = Newtonsoft.Json.JsonConvert.DeserializeObject<JObject>(responseContent);
                    return retJson;
                }
            }
            catch (WebException webException)
            {
                if (webException.Response != null)
                {
                    using (var reader = new StreamReader(webException.Response.GetResponseStream()))
                    {
                        var responseContent = reader.ReadToEnd();
                        //Console.WriteLine("responseContent:" + responseContent);
                    }
                }
            }
            return null;
        }

        /// <summary>
        /// Http Put
        /// </summary>
        /// <param name="url"></param>
        /// <param name="headers">headers</param>
        /// <param name="content">the json content to put</param>
        /// <returns></returns>
        public static JObject DoPut(string url, Dictionary<string, string> headers,string content)
        {
            //Console.WriteLine("url:" + url);
            var request = WebRequest.Create(url);
            request.ContentType = "application/json";
            if (null != headers)
            {
                //Console.WriteLine("headers start");
                foreach (string key in headers.Keys)
                {
                    //Console.WriteLine(key + ":" + headers[key]);
                    request.Headers.Add(key, headers[key]);
                }
                //Console.WriteLine("headers end");
            }
            request.Method = "PUT";
            if (!string.IsNullOrEmpty(content))
            {
                //Console.WriteLine("content:" + content);
                using (var writer = new StreamWriter(request.GetRequestStream()))
                {
                    writer.Write(content);
                }
            }

            try
            {
                var response = request.GetResponse();
                using (var reader = new StreamReader(response.GetResponseStream()))
                {
                    var responseContent = reader.ReadToEnd();
                    //Console.WriteLine("responseContent:" + responseContent);
                    var retJson =
                        Newtonsoft.Json.JsonConvert.DeserializeObject<JObject>(responseContent);
                    return retJson;
                }

            }
            catch (WebException webException)
            {
                if (webException.Response != null)
                {
                    using (var reader = new StreamReader(webException.Response.GetResponseStream()))
                    {
                        var responseContent = reader.ReadToEnd();
                        //Console.WriteLine("responseContent:" + responseContent);
                    }
                }
            }

            return null;
        }
    }
}
