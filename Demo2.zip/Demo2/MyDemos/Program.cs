﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.IdentityModel.Clients.ActiveDirectory;
using Microsoft.Store.PartnerCenter;
using Microsoft.Store.PartnerCenter.Exceptions;
using Microsoft.Store.PartnerCenter.Extensions;
using Microsoft.Store.PartnerCenter.Models.Query;
using System.Globalization;
using Microsoft.Store.PartnerCenter.Models;
using Microsoft.Store.PartnerCenter.Models.Customers;
using Microsoft.Store.PartnerCenter.Models.Orders;
using System.Web;
using MyDemos.Services;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;

namespace MyDemos
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                 //login Azure AD, for partner center sdk, you can use the "common" as the tenant id
                 var aadAuthenticationResult = Program.LoginToAad("common",SettingsHelper.PartnerCenterApiResourceId).Result;

                 //set to use the public partner center api
                 PartnerService.Instance.ApiRootUrl = SettingsHelper.PartnerCenterApiEndpoint;

                 //get the credential
                 var authToken = new AuthenticationToken(aadAuthenticationResult.AccessToken, aadAuthenticationResult.ExpiresOn);
                 IPartnerCredentials credentials = PartnerCredentials.Instance.GenerateByUserCredentials(SettingsHelper.ClientId, authToken);
                 //get the partner operations
                 IPartner partner = PartnerService.Instance.CreatePartnerOperations(credentials);

                /*[Test]#1:Create new customner
                CreateCustomer(partner);
                */

                /*[Test]#2: Query paged customers with keyword in company name
                QueryCustomers(partner, "your company name", 100);
                */

                /*[Test]#3: query available offer
                GetOffers(partner,500)
                */

                /*[Test]#4:Create offer for special customer, you can get customer id from test 2
                PlaceOrder(partner, "*********************");
                */

                /*[Test]#5 
                //customerId/tenantId/Directory Id, you can use QueryCustomers to get the customer id and subscription id 
                string customerId = "********************";
                //azure subscription id
                string subscriptionId = "*************";
                string roleNameToAssign = "Owner";
                //partner center dashboard>customer>customer details>users and licenses
                string userMailToAssign = "admin@<domainPrefix>.onmicrosoft.com";

                //assign user to subscription
                AssignUserToSubscriptionWithRole(customerId,subscriptionId,roleNameToAssign,userMailToAssign);
                */

                /*[Test]#6 query the usage records
                  //customerId/tenantId/Directory Id, you can use QueryCustomers to get the customer id and subscription id 
                string customerId = "********************";
                //azure subscription id
                string subscriptionId = "*************";

                QueryUtilization(partner, customerId, subscriptionId);
                */

                Console.WriteLine("Press [Enter] to exit");
                Console.ReadLine();
            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("error source：" + ex.Source);
                Console.WriteLine("error message：" + ex.Message);
            }
        }

        /// <summary>
        /// Login in azure ad and get the credential
        /// </summary>
        /// <param name="tenantId">the domain</param>
        /// <param name="resource">the resouce to get access token</param>
        /// <returns></returns>
        private static async Task<AuthenticationResult> LoginToAad(string tenantId, string resource)
        {
            // auth from azure ad 
            var addAuthority = new UriBuilder(SettingsHelper.AadAuthority + tenantId);
            UserCredential userCredentials = new UserCredential(SettingsHelper.UserId,
                                                    SettingsHelper.UserPassword);
            AuthenticationContext authContext = new AuthenticationContext(addAuthority.Uri.AbsoluteUri);
            return await authContext.AcquireTokenAsync(resource,
                                                       SettingsHelper.ClientId,
                                                       userCredentials);
        }

        /// <summary>
        /// Use the Azure Management API to query roleDefinationId
        /// </summary>
        /// <param name="roleName">customer's role name </param>
        /// <returns></returns>
        private static string QueryRoleDefinitionIdByRoleName(string tenantId, string subscriptionId, string roleName)
        {
            string tokenAzureRM = Program.LoginToAad(tenantId, SettingsHelper.AzureRMApiResourceId).Result.AccessToken;
            string filter = HttpUtility.UrlEncode(string.Format("roleName eq '{0}'", roleName));
            JObject retJson = RoleDefinitionsService.List(tokenAzureRM, subscriptionId, filter);
            return (string)retJson["value"][0]["id"];
        }

        /// <summary>
        /// Use Azure AD Graph API to query user's Object ID
        /// </summary>
        /// <param name="mail">user's email </param>
        /// <returns>user's Object ID</returns>
        private static string QueryObjectIdByMail(string tenantId,string mail)
        {
            string tokenADGraph = Program.LoginToAad(tenantId, SettingsHelper.AzureADGraphApiResourceId).Result.AccessToken;
            String filter = HttpUtility.UrlEncode(string.Format("mail eq '{0}' or userPrincipalName eq '{1}'", mail.ToLower(), mail.ToLower()));
            JObject retJson = UsersService.List(tenantId,tokenADGraph, filter);
            return (string)retJson["value"][0]["objectId"];
        }

        /// <summary>
        /// Assign user to azure subscription with special role name 
        /// </summary>
        /// <param name="subscriptionId">customer's azure subscription ID</param>
        /// <param name="roleName">role name to assign to user </param>
        /// <param name="mail">the user will be assign to subscription</param>
        private static void AssignUserToSubscriptionWithRole(string tenantId, string subscriptionId, string roleName, string mail)
        {
            Console.WriteLine("Start to assign user [{0}] with role [{1}] to subscription [{2}]", mail, roleName, subscriptionId);
            string objectId = QueryObjectIdByMail(tenantId,mail);
            string roleDefinitionId = QueryRoleDefinitionIdByRoleName(tenantId,subscriptionId, roleName);

            string tokenAzureRM = Program.LoginToAad(tenantId, SettingsHelper.AzureRMApiResourceId).Result.AccessToken;
            JObject retJson = RoleAssignmentsService.Create(tokenAzureRM, subscriptionId, roleDefinitionId, objectId);
            Console.WriteLine("Assign successfully");
        }

        /// <summary>
        /// Query the utilization of customer's azure subscription
        /// </summary>
        /// <param name="partner"></param>
        /// <param name="customerId">the customer's id/tenant id/directory id</param>
        /// <param name="subscriptionId">the customer's azure subscription id</param>
        private static void QueryUtilization(IPartner partner, string customerId, string subscriptionId)
        {
            // Retrieve the utilization records for the last year in pages of 100 records.
            // If you want to retrieve other records, please modify the paramter by yourself
            var utilizationRecords = partner.Customers[customerId].Subscriptions[subscriptionId].Utilization.Azure.Query(
                DateTimeOffset.Now.AddYears(-1),
                DateTimeOffset.Now, showDetails: true, //show details will include tags
                size: 100);

            // Create an Azure utilization enumerator which will aid us in traversing the utilization pages.
            var utilizationRecordEnumerator = partner.Enumerators.Utilization.Azure.Create(utilizationRecords);
            int pageNumber = 1;

            string tokenAzureRM = Program.LoginToAad(customerId, SettingsHelper.AzureRMApiResourceId).Result.AccessToken;

            JObject retJson = ResouceService.ListProvider(tokenAzureRM, subscriptionId);
            while (utilizationRecordEnumerator.HasValue)
            {


                foreach (var record in utilizationRecordEnumerator.Current.Items)
                {
                    string tags = "";
                    string utags = "";
                    // OPTION1 - this will only work with showDetails:true option
                    // reports tags applied at time usage record arrived to commerce system
                    if (record.InstanceData.Tags != null)
                    {

                        StringBuilder builder = new StringBuilder();
                        foreach (string tag in record.InstanceData.Tags.Keys)
                        {
                            builder.AppendFormat("{0}:{1}|", tag, record.InstanceData.Tags[tag]);
                        }
                        utags = builder.ToString();
                    }
                    // END - this will only work with showDetails:true option
                    //OPTION 2- Parse resouce name from resouce uri 
                    //          reports tags applied at to resource now (if resource still exists)
                    string resourceUri = record.InstanceData.ResourceUri.ToString();
                    int rsgStart = resourceUri.ToLower().IndexOf("/resourcegroups/");
                    int rsgNameStart = rsgStart + 16;
                    int rsgNameLength = resourceUri.Substring(rsgNameStart).IndexOf("/");
                    string rsgName = resourceUri.Substring(rsgNameStart, rsgNameLength);


                    //Based on the resouceuri , you can parse the resouce name;
                    //if the resouce still exists, you can try to query the resouces's details to 
                    //get the tags. but if the resouce has been removed , errors will occur.
                    try
                    {
                        //parse the provider name 
                        int providerStart = resourceUri.ToLower().IndexOf("/providers/");
                        int providerNameStart = providerStart + 11;
                        int providerNameLength = resourceUri.Substring(providerNameStart).IndexOf("/");
                        string providerName = resourceUri.Substring(providerNameStart, providerNameLength);
                        //parse the resouce type name 
                        int resouceStart = resourceUri.IndexOf(string.Format("/{0}/", providerName));
                        int resourceTypeStart = resouceStart + providerName.Length + 2;
                        int resourceTypeNameLength = resourceUri.Substring(resourceTypeStart).IndexOf("/");
                        string resourceTypeName = resourceUri.Substring(resourceTypeStart, resourceTypeNameLength);
                        //use the provider name and resouce type to parse the avaliable api version 
                        var provider = retJson["value"].ToObject<List<Dictionary<string, object>>>().Where(x => x["id"].Equals(string.Format("/subscriptions/{0}/providers/{1}", subscriptionId.ToLower(), providerName))).First();
                        var resourceTypes = ((JArray)provider["resourceTypes"]).ToObject<List<Dictionary<string, object>>>();
                        var resourceType = resourceTypes.Where(x => x["resourceType"].Equals(resourceTypeName)).First();
                        JArray apiVersions = (JArray)resourceType["apiVersions"];
                        string apiVersion = apiVersions[0].ToString();
                        //query the resouce detials and get tags 
                        tags = ResouceService.ListTags(tokenAzureRM, resourceUri, apiVersion);
                    }
                    catch (Exception e)
                    {
                        // Console.WriteLine(e.Message);
                    }

                    Console.WriteLine("Name:{0}|Resouce Group Name:{1}|RTags:{2}|UTags:{3}|Quantity:{4}|Unit:{5}|UsageStartTime:{6}|UsageEndTime:{7}", record.Resource.Name, rsgName, tags, utags, record.Quantity, record.Unit, record.UsageStartTime, record.UsageEndTime);
                }
                utilizationRecordEnumerator.Next();
                pageNumber++;
                //break; this is for test 
            }
        }

        /// <summary>
        /// Query paged customers 
        /// </summary>
        /// <param name="partner"></param>
        /// <param name="pageSize">page size</param>
        private static void QueryCustomers(IPartner partner,int pageSize)
        {
            var myQuery = QueryFactory.Instance.BuildIndexedQuery(pageSize, 0);
            var customersPage = partner.Customers.Query(myQuery);


            var customersEnumerator = partner.Enumerators.Customers.Create(customersPage);
            int i = 0, pageNumber = 0;
            while (customersEnumerator.HasValue)
            {
                ++pageNumber;
                var customers = customersEnumerator.Current;
                StringBuilder report = new StringBuilder();
                report.AppendFormat("The #{0} page exists {1} customers\n", pageNumber, customers.TotalCount);
                report.AppendFormat("Index,Customer ID,Name,Domain:\n");
                foreach (var customer in customers.Items)
                {
                    ++i;
                    try
                    {
                        report.AppendFormat("\n#{0},{1},{2},{3}\n", i, customer.Id, customer.CompanyProfile.CompanyName, customer.CompanyProfile.Domain);

                        // get the customer's subcriptions
                        var subscriptions = partner.Customers.ById(customer.Id).Subscriptions.Get();
                        if (subscriptions.TotalCount == 0)
                        {
                            report.AppendFormat("\nNo subscription exists\n");
                        }
                        else
                        {
                            report.AppendFormat("\nSubscription ID,Subscription Name,Subscription Quantity\n");
                            foreach (var subscription in subscriptions.Items)
                            {
                                //add the subscription
                                report.AppendFormat("{0},{1},{2}\n", subscription.Id, subscription.FriendlyName, subscription.Quantity);
                            }
                        }

                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("Succeed to get the #{0} customer at the #{1} page!",i, pageNumber);
                    }
                    catch (PartnerException)
                    {
                        //ignore some 403 errors related to Commerce and BEC 
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Fail to get the #{0} customer at the #{1} page!", i, pageNumber);
                    }

                    Console.ForegroundColor = ConsoleColor.White;
                }
                //print the report
                Console.WriteLine(report);

                customersEnumerator.Next();
            }



            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Press any key to continue...");
            Console.ReadLine();
        }

        /// <summary>
        /// Query paged customers via keyword in company name
        /// </summary>
        /// <param name="partner"></param>
        /// <param name="keywords">the keyword in company name</param>
        /// <param name="pageSize">page size</param>
        private static void QueryCustomers(IPartner partner, string keywords,int pageSize)
        {
            // query the customer via keyword in company name
            var fieldFilter = new SimpleFieldFilter(CustomerSearchField.CompanyName.ToString(), FieldFilterOperation.StartsWith, keywords);
            var myQuery = QueryFactory.Instance.BuildIndexedQuery(pageSize,0,fieldFilter);
            var customersPage = partner.Customers.Query(myQuery);


            var customersEnumerator = partner.Enumerators.Customers.Create(customersPage);
            int i = 0, pageNumber = 0;
            while (customersEnumerator.HasValue)
            {
                ++pageNumber;
                var customers = customersEnumerator.Current;
                StringBuilder report = new StringBuilder();
                report.AppendFormat("The #{0} page exists {1} customers\n", pageNumber, customers.TotalCount);
                report.AppendFormat("Index,Customer ID,Name,Domain:\n");
                foreach (var customer in customers.Items)
                {
                    ++i;
                    try
                    {
                        report.AppendFormat("\n#{0},{1},{2},{3}\n", i, customer.Id, customer.CompanyProfile.CompanyName, customer.CompanyProfile.Domain);

                        // get the customer's subcriptions
                        var subscriptions = partner.Customers.ById(customer.Id).Subscriptions.Get();
                        if (subscriptions.TotalCount == 0)
                        {
                            report.AppendFormat("\nNo subscription exists\n");
                        }
                        else
                        {
                            report.AppendFormat("\nSubscription ID,Subscription Name,Subscription Quantity\n");
                            foreach (var subscription in subscriptions.Items)
                            {
                                //add the subscription
                                report.AppendFormat("{0},{1},{2}\n", subscription.Id, subscription.FriendlyName, subscription.Quantity);
                            }
                        }

                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("Succeed to get the #{0} customer at the #{1} page!", i, pageNumber);
                    }
                    catch (PartnerException)
                    {
                        //ignore some 403 errors related to Commerce and BEC 
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Fail to get the #{0} customer at the #{1} page!", i, pageNumber);
                    }

                    Console.ForegroundColor = ConsoleColor.White;
                }
                //print the report
                Console.WriteLine(report);

                customersEnumerator.Next();
            }



            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Press any key to continue...");
            Console.ReadLine();
        }
        /// <summary>
        /// Create new customer
        /// </summary>
        /// <param name="partnerOperations"></param>
        /// <returns></returns>
        private static Customer CreateCustomer(IPartner partnerOperations)
        {
            //set the customer's information
            var domainPrefix = "EMD18031401";
            string strCompnayName = "EMD18031401";
            Customer newCustomer = new Customer()
            {
                // set the company profile
                CompanyProfile = new CustomerCompanyProfile()
                {
                    // set the domain 
                    Domain = string.Format(CultureInfo.InvariantCulture, "{0}.onmicrosoft.com", domainPrefix),
                    // set company name
                    CompanyName = strCompnayName
                },
                //set the billing profile
                BillingProfile = new CustomerBillingProfile
                {
                    Culture = "en-US",
                    Language = "en",
                    FirstName = "Test",
                    LastName = "EMD",
                    Email = string.Format("daniel@{0}.onmicrosoft.com", domainPrefix),
                    CompanyName = strCompnayName,

                    DefaultAddress = new Address()
                    {
                        FirstName = "Test",
                        LastName = "EMD",
                        AddressLine1 = "1 Microsoft Way",
                        AddressLine2 = "Building 1",
                        City = "Redmond",
                        State = "WA",
                        Country = "US",
                        PostalCode = "98052",
                        PhoneNumber = "415-555-1212"
                    }
                }
            };
            return partnerOperations.Customers.Create(newCustomer);
        }

        /// <summary>
        /// get the available offers by country
        /// </summary>
        /// <param name="partnerOperations"></param>
        /// <param name="size"></param>
        private static void GetOffers(IPartner partnerOperations, Int32 size)
        {
            var offers = partnerOperations.Offers.ByCountry("US").Get(0, size);

            StringBuilder report = new StringBuilder();
            report.Append("Offer ID, Category Name, SalesGroupId, Offer Name\n");
            foreach (var offer in offers.Items)
            {
                report.AppendFormat(" {0}, {1}, {2},{3}\n", offer.Id, offer.Category.Name, offer.SalesGroupId, offer.Name);
            }

            // list offers
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("The available offers...");
            Console.WriteLine(report);
        }

        /// <summary>
        /// Create the subscription/order for customer,like azure ,powerbi ,office365 etc
        /// </summary>
        /// <param name="partnerOperations"></param>
        /// <param name="customerId">the customer id</param>
        public static void PlaceOrder(IPartner partnerOperations, string customerId)
        {

            //you can add multi order items in same order
            //but only offers with same salesgroupid can put into same order.
            //for example , if you try to put the powerbi pro and azure subscritpipon into same order, error will occur
            var lineItems = new List<OrderLineItem>();
            /* 
             *
            lineItems.Add(new OrderLineItem
            {
                LineItemNumber = 0,
                OfferId = "800F4F3B-CFE1-42C1-9CEA-675512810488",
                FriendlyName = "Power BI Pro - MSFT",
                Quantity = 1
            });

            lineItems.Add(new OrderLineItem
            {
                LineItemNumber = 1,
                OfferId = "A6ACBC1C-9D2A-482A-ABDA-DFB9285E301E",
                FriendlyName = "Power BI Pro - Government",
                Quantity = 1
            });
            */


            //create the azure subscription
            lineItems.Add(new OrderLineItem
            {
                 LineItemNumber = 0,
                 OfferId = "MS-AZR-0146P",
                 FriendlyName = "CSP Microsoft Azure",
                 Quantity = 1
            });


            // create order
            var order = new Order
            {
                ReferenceCustomerId = customerId,
                LineItems = lineItems
            };

            
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("create order...");

            try
            {
                partnerOperations.Customers.ById(customerId).Orders.Create(order);
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("order created successfully!");
            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("error occurs", ex.Message);
            }
        }

        /// <summary>
        /// Romove the customer
        /// </summary>
        /// <param name="partnerOperations"></param>
        /// <param name="CustomerID"> the customer's id to remove</param>
        private static void DeleteCustomer(IPartner partnerOperations, string CustomerID)
        {
            string CustomerName = partnerOperations.Customers.ById(CustomerID).Profiles.Billing.Get().CompanyName;
            partnerOperations.Customers.ById(CustomerID).Delete();

            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine(CustomerName + "has been deleted...");
        }
    }
}
